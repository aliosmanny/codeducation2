import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_app/main.dart'; // Proje adını kontrol et
import 'package:flutter_app/login_screen.dart'; // LoginScreen doğru bir şekilde import ediliyor mu?

void main() {
  testWidgets('LoginScreen initial state test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(
      MaterialApp(
        home: LoginScreen(), // Test edilen ekran
      ),
    );

    // Test LoginScreen için belirli widgetları bul.
    expect(find.byType(TextField), findsNWidgets(2)); // 2 TextField varsa
    expect(find.byType(ElevatedButton), findsOneWidget); // Bir buton varsa
  });
}
